/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-20-15:55:05
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

public interface IMapCreater
{
    int[,] CreateMap();    				
}

