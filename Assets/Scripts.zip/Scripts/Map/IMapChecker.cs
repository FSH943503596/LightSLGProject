/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-20-16:00:14
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

public interface IMapChecker
{
    void CheckMap(int[,] map);				
}

