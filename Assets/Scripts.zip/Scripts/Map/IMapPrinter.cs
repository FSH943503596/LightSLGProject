/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-20-16:01:49
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

public interface IMapPrinter
{
    void PrintMap(int[,] map, int xStart, int xCount, int zStart, int zCount);
}

