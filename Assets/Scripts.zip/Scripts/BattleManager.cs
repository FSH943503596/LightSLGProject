/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-14-15:39:49
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using SUIFW;
using System;
using UnityEngine;

public class BattleManager : IBattleManager
{
    public static readonly BattleManager Instance = new BattleManager();

    public BattleMapSystem mapSystem;
    public BattleBuildingSystem buildingSystem;
    public BattlePlayerSystem playerSystem;
    public SLGInputSystem inputSystem;
    private BattleManager() { }

    public bool IsBattleOver { get; set; }

    public void Initinal()
    {
        mapSystem = new BattleMapSystem(this);
        mapSystem.Initialize();
        buildingSystem = new BattleBuildingSystem(this);
        buildingSystem.Initialize();
        playerSystem = new BattlePlayerSystem(this);
        playerSystem.Initialize();
        inputSystem = new SLGInputSystem(this);
        inputSystem.Initialize();


        playerSystem.InitPlayers();

        //调整相机位置到玩家位置

        Vector3 vector = playerSystem.UserMainBasePosition;
        vector.Scale(Vector3.right + Vector3.forward);
        vector.y = mapSystem.GetCameraPositon().y;
        mapSystem.SetCameraPosition(vector);

        mapSystem.PrintMap();

        ShowBattleUI();
    }

    private void ShowBattleUI()
    {
        //显示建造面板
        UIManager.Instance.ShowUIForms(GlobalSetting.UI_ConstructionUIForm);
    }

    public void Release()
    {
        mapSystem.Release();
    }

    public void Update()
    {
        inputSystem.Update();
        mapSystem.Update();
    }

    public void ShowConstraction(Transform builidTF)
    {
        inputSystem.LongTapItem = builidTF;
    }

    public void CancelConstraction()
    {
        inputSystem.LongTapItem = null;
        inputSystem.DragItem = null;
    }
}