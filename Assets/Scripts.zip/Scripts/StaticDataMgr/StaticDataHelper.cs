
using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;

namespace StaticData
{
    public static class StaticDataHelper
    {
        static StaticDataHelper()
        {

        }
    }
}