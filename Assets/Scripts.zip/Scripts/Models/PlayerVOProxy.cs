/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-25-11:54:55
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using PureMVC.Patterns;
using System.Collections.Generic;
using UnityEngine;

public class PlayerVOProxy : Proxy
{
    new public const string NAME = "PlayerProxy";

    private IList<PlayerVO> _Players
    {
        get
        {
            return base.Data as IList<PlayerVO>;
        }
    }

    public PlayerVOProxy() : base(NAME, new List<PlayerVO>())
    {        
    }

    public PlayerVO CreatePlayer(string name, byte group)
    {
        PlayerVO player = new PlayerVO(name, group);

        _Players.Add(player);

        return player;
    }

    public void ClearPlayers()
    {
        _Players.Clear();
    }

    public IList<MainBaseVO> GetUsersMainBaseList()
    {
        for (int i = 0; i < _Players.Count; i++)
        {
            if (_Players[i].Id == 1) return _Players[i].MainBases;
        }

        return null;
    }

    public bool IsCanConstructionUserBuilding(int playerID, IBuilding building)
    {
        PlayerVO player = _Players[playerID];
        IList<MainBaseVO> mainbases = player.MainBases;
        List<IBuilding> buildings = null;
        Vector3Int downLeft;
        Vector3Int middle;
        Vector3Int upRight;
        Vector3Int downLeftb;
        Vector3Int upRightb;

        if (mainbases.Count == 0) return false;

        for (int i = 0; i < mainbases.Count; i++)
        {
            downLeft = building.TilePositon - new Vector3Int(building.Rect.position.x, 0, building.Rect.position.y);
            middle = downLeft;
            if (!mainbases[i].IsIn(middle)) continue;
            middle.x += building.Rect.size.x - 1;
            if (!mainbases[i].IsIn(middle)) continue;
            middle.z += building.Rect.size.y - 1;
            upRight = middle;
            if (!mainbases[i].IsIn(middle)) continue;
            middle.x -= building.Rect.size.x - 1;
            if (!mainbases[i].IsIn(middle)) continue;

            buildings = mainbases[i].OwnBuildings;
            for (int j = 0; j < buildings.Count; j++)
            {
                downLeftb = buildings[j].TilePositon - new Vector3Int(building.Rect.position.x, 0, building.Rect.position.y);
                upRightb = downLeftb + new Vector3Int(buildings[j].Rect.width - 1, 0, buildings[j].Rect.height - 1);
                if (downLeft.x <= upRightb.x && upRight.x >= downLeftb.x && downLeft.z <= upRightb.z && upRight.z >= downLeftb.z)
                {
                    return false;
                }
            }
            return true;
        }

        return false;
    }

    public PlayerVO GetUserVO()
    {
        return _Players[0];
    }

    public MainBaseVO GetMainBaseUserBuildingBelongTo(IBuilding building)
    {
        if (building.BuildingType == E_Building.MainBase) return building as MainBaseVO;

        PlayerVO player = GetUserVO();
        IList<MainBaseVO> mainbases = player.MainBases;
        List<IBuilding> buildings = null;
        Vector3Int downLeft;
        Vector3Int upRight;
        Vector3Int downLeftb;
        Vector3Int upRightb;

        if (mainbases.Count == 0) return null;

        for (int i = 0; i < mainbases.Count; i++)
        {
            downLeft = building.TilePositon - new Vector3Int(building.Rect.position.x, 0, building.Rect.position.y);
            if (!mainbases[i].IsIn(downLeft)) continue;
            downLeft.x += building.Rect.size.x - 1;
            if (!mainbases[i].IsIn(downLeft)) continue;
            downLeft.z += building.Rect.size.y - 1;
            upRight = downLeft;
            if (!mainbases[i].IsIn(downLeft)) continue;
            downLeft.x -= building.Rect.size.x - 1;
            if (!mainbases[i].IsIn(downLeft)) continue;

            buildings = mainbases[i].OwnBuildings;
            for (int j = 0; j < buildings.Count; j++)
            {
                downLeftb = buildings[j].TilePositon - new Vector3Int(building.Rect.position.x, 0, building.Rect.position.y);
                upRightb = downLeftb + new Vector3Int(buildings[j].Rect.width - 1, 0, buildings[j].Rect.height - 1);
                if (downLeft.x <= upRightb.x && upRight.x >= downLeftb.x && downLeft.z <= upRightb.z && upRight.z >= downLeftb.z)
                {
                    return null;
                }
            }
            return mainbases[i];
        }

        return null;
    }
}

