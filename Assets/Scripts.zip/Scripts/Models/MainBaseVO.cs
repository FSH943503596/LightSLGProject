﻿/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-22-17:07:21
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using System;
using System.Collections.Generic;
using UnityEngine;

public class MainBaseVO : IBuilding
{
    public static string SubPrefabName = "SubBase";
    private int radius = 4;
    private List<IBuilding> ownBuildings = new List<IBuilding>();
    private PlayerVO ower;
    private bool isMain = false;


    public MainBaseVO()
    {
        rect = new RectInt(0, 0, 1, 1);
        PrefabName = "MainBase";
        buildingType = E_Building.MainBase;
        ownBuildings.Add(this);
    }

    public MainBaseVO(PlayerVO ower) : this()
    {
        if (ower != null)
        {
            this.ower = ower;
            isMain = ower.AddMainBases(this);
            if (!isMain) PrefabName = SubPrefabName;
        }
    }

    public int Radius { get => radius; set => radius = value; }

    public Vector3Int StartTilePositonInMap
    {
        get {
            return tilePositon - new Vector3Int(radius - 1, 0, radius -1);
        }
    }

    public bool IsMain { get => isMain; set => isMain = value; }
    public List<IBuilding> OwnBuildings { get => ownBuildings; }

    public bool AddBuilding(IBuilding building)
    {
        if (building == null || building.PrefabName.Equals("MainBase")) return false;

        if (ownBuildings.Contains(building)) return false;

        ownBuildings.Add(building);

        return true;
    }

    public bool IsIn(Vector3Int pos)
    {
        return Mathf.Abs(pos.x - tilePositon.x) + Mathf.Abs(pos.z - tilePositon.z) < radius;
    }
}

