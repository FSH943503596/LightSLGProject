/*
 *	Author:	贾树永
 *	CreateTime:	2019-03-01-11:40:50
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using PureMVC.Patterns;
using System;
using System.Collections.Generic;

public class BuildingProxy : Proxy
{
    new public const string NAME = "BuildingProxy";

    private IList<IBuilding> _Buildings
    {
        get
        {
            return base.m_data as IList<IBuilding>;
        }
    }

    public BuildingProxy() : base(NAME, new List<IBuilding>())
    {   
    }
}

