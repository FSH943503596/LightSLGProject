/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-25-15:26:18
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using PureMVC.Interfaces;
using PureMVC.Patterns;
using System;

public class GameFacade : Facade
{
    protected GameFacade() { }

    private ISceneStateController _SceneStateController;

    new public static IFacade Instance
    {
        get
        {
            if (m_instance == null)
            {
                lock (m_staticSyncRoot)
                {
                    if (m_instance == null)
                    {
                        m_instance = new GameFacade();
                    }
                }
            }

            return m_instance;
        }
    }

    public ISceneStateController sceneStateController { get => _SceneStateController; set => _SceneStateController = value; }

    protected override void InitializeModel()
    {
        base.InitializeModel();

        RegisterProxy(new PlayerVOProxy());
        RegisterProxy(new MainBaseVOProxy());
        RegisterProxy(new BuildingProxy());
        RegisterProxy(new MapVOProxy());
    }

    protected override void InitializeView()
    {
        base.InitializeView();
        RegisterMediator(new MainBasesMediator());
        RegisterMediator(new LoginMediator());
        RegisterMediator(new MainMediator());
        RegisterMediator(new ConstructionMediator());
    }

    protected override void InitializeController()
    {
        base.InitializeController();
        RegisterCommand(GlobalSetting.UI_ConstructionUIForm, typeof(ConstructionCommand));
        RegisterCommand(GlobalSetting.UI_LoginUIForm, typeof(LoginUIFormCommand));
        RegisterCommand(GlobalSetting.UI_MainUIForm, typeof(MainUIFormCommand));

        RegisterCommand(GlobalSetting.Cmd_ExitGame, typeof(ExitGameCommand));
        RegisterCommand(GlobalSetting.Cmd_LoginGame, typeof(LoginCommand));
        RegisterCommand(GlobalSetting.Cmd_StartBattle, typeof(StartBattleCommand));
        RegisterCommand(GlobalSetting.Cmd_ShowConstruction, typeof(ShowConstructionCommand));
        RegisterCommand(GlobalSetting.Cmd_CancelConstruction, typeof(CancelConstructionCommand));
        RegisterCommand(GlobalSetting.Cmd_ConfirmConstruction, typeof(ConfirmConstructionCommand));
    }  
}

