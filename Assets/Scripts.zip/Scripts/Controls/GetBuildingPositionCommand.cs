/*
 *	Author:	贾树永
 *	CreateTime:	2019-03-01-09:58:54
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using System;

public class GetBuildingPositionCommand
{
				
}

