/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-22-17:00:39
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using System;
using UnityEngine;

public abstract class IBuilding
{
    protected string prefabName = "Building";
    protected Vector3Int tilePositon;  
    protected RectInt rect = new RectInt(0,0,4,1);
    protected E_Building buildingType = E_Building.None;
    protected int rotateValue = 0;

    public Vector3Int TilePositon { get => tilePositon; set => tilePositon = value; }
    public RectInt Rect { get => rect; set => rect = value; }
    public string PrefabName { get => prefabName; set => prefabName = value; }
    public E_Building BuildingType { get => buildingType; set => buildingType = value; }
    public int RotateValue { get => rotateValue; }

    public void Rotate()
    {
        if (rotateValue == 0)
        {
            rotateValue = 270;
            rect = new RectInt(new Vector2Int(rect.size.y - rect.position.y - 1, rect.position.x), 
                               new Vector2Int(rect.size.y, rect.size.x));
        }
        else
        {
            rotateValue = 0;
            rect = new RectInt(new Vector2Int(rect.position.y, rect.size.x - rect.position.x - 1),
                               new Vector2Int(rect.size.y, rect.size.x));
        }
    }
}

