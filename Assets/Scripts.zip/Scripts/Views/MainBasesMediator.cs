/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-26-13:36:42
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using PureMVC.Interfaces;
using PureMVC.Patterns;
using SUIFW;
using System;
using System.Collections.Generic;
using UnityEngine;

public class MainBasesMediator : Mediator
{
    new public const string NAME = "MainBasesMediator";

    private Transform buildingParent;
    private IList<MainBase> mainBases
    {
        get {
            return base.ViewComponent as IList<MainBase>;
        }
    }

    public MainBasesMediator() : base(NAME, new List<MainBase>())
    {
        
    }

    public void InitMainBaseMediator()
    {
        this.buildingParent = GameObject.FindGameObjectWithTag(GlobalSetting.TAG_BUILDING_PARENT_NAME).transform;
    }

    public void AddMainBase(MainBase mainBase)
    {
        if (mainBase != null)
        {
            mainBases.Add(mainBase);
        }
    }

    public override IList<string> ListNotificationInterests()
    {
        return new List<string>()
        {
            GlobalSetting.Msg_InitMainBaseMediator,
            GlobalSetting.Msg_CreateMainBase
        };
    }

    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case GlobalSetting.Msg_InitMainBaseMediator:
                InitMainBaseMediator();
                break;
            case GlobalSetting.Msg_CreateMainBase:
                MainBaseVO mainBaseVO = notification.Body as MainBaseVO;
                if (mainBaseVO != null)
                {
                    CreateMainBase(mainBaseVO);
                }
                break;
            default:
                break;
        }
    }

    private void CreateMainBase(MainBaseVO mainBaseVO)
    {
        GameObject go = PoolManager.Instance.GetObject(mainBaseVO.PrefabName, LoadAssetType.Normal, buildingParent);
        go.transform.localPosition = mainBaseVO.TilePositon;
        MainBase mainBase = go.GetComponent<MainBase>() ?? go.AddComponent<MainBase>();
        AddMainBase(mainBase);
    }
}

