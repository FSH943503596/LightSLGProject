/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-26-14:03:09
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/
using UnityEngine;

public class Building : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
