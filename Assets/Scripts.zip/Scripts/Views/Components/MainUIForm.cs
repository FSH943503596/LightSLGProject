/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-28-14:25:33
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using SUIFW;
using System;
using UnityEngine;
using UnityEngine.UI;

public class MainUIForm : BaseUIForm
{
    [SerializeField] private Button _BtnStartBattle;

    public Button btnStartBattle { get => _BtnStartBattle;}
}

