/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-27-16:36:53
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using PureMVC.Interfaces;
using PureMVC.Patterns;
using SUIFW;
using System;
using System.Collections.Generic;
using UnityEngine;

public class ConstructionMediator : Mediator
{
    new public static string NAME = "ConstructionMediator";

    private string ConstructionHUD1Name = "HUD_ConstructionOne";
    private string ConstructionHUD4Name = "HUD_ConstructionFour";

    private bool _IsShowBuildingList = true;

    private Transform _BuildingParnet;
    private MapVOProxy _MapProxy;
    private PlayerVOProxy _UserProxy;
    private IBuilding _Building;
    private Transform _BuildingTF;
    private HUDConstruction _CurrentIndicator;
    private Func<bool> _IsCanConfirmFunc;

    private ConstructionUIForm uiForm
    {
        get {
            return base.ViewComponent as ConstructionUIForm;
        }
    }

    public bool IsShowBuildingList { get => _IsShowBuildingList; }

    public ConstructionMediator() : base(NAME) { }

    public override IList<string> ListNotificationInterests()
    {
        return new List<string>()
        {
            GlobalSetting.Msg_InitConstructionMediator
        };
    }

    public override void HandleNotification(INotification notification)
    {
        switch (notification.Name)
        {
            case GlobalSetting.Msg_InitConstructionMediator:
                ConstructionUIForm constructionUIForm = notification.Body as ConstructionUIForm;
                if (constructionUIForm)
                {
                    InitConstructionMediator(constructionUIForm);
                }
                break;
            default:
                break;
        }
    }
    public void InitConstructionMediator(ConstructionUIForm baseUIForm)
    {
        base.ViewComponent = baseUIForm;

        ConstructionUIForm form = uiForm;

        uiForm.btnMainBase.onClick.AddListener(() => CreateBuilding(E_Building.MainBase));
        uiForm.btnMilitaryCamp.onClick.AddListener(() => CreateBuilding(E_Building.MilitaryCamp));
        uiForm.btnFarmLand.onClick.AddListener(() => CreateBuilding(E_Building.FarmLand));
        uiForm.btnGoldMine.onClick.AddListener(() => CreateBuilding(E_Building.GoldMine));

        uiForm.btnCancel.onClick.AddListener(Cancel);
        uiForm.btnConfirm.onClick.AddListener(Confirm);
        uiForm.btnInfo.onClick.AddListener(ShowBuildingInfo);
        uiForm.btnTurn.onClick.AddListener(RotateBuilding);

        _BuildingParnet = GameObject.FindGameObjectWithTag(GlobalSetting.TAG_BUILDING_PARENT_NAME).transform;

        _MapProxy = Facade.RetrieveProxy(MapVOProxy.NAME) as MapVOProxy;

        _UserProxy = Facade.RetrieveProxy(PlayerVOProxy.NAME) as PlayerVOProxy;

        CreateBuildingIndicator();
    }

    private void CreateBuildingIndicator()
    {
        PoolManager.Instance.IncreaseObjectCache(ConstructionHUD1Name, 1);
        PoolManager.Instance.IncreaseObjectCache(ConstructionHUD4Name, 1);    
    }

    private void Confirm()
    {
        //判断是否能够放置
        if (_IsCanConfirmFunc())
        {
            //取消指示器
            _CurrentIndicator.transform.SetParent(null);
            PoolManager.Instance.HideObjet(_CurrentIndicator.gameObject);
            //放置建筑
            _BuildingTF.localPosition = _Building.TilePositon;
            //显示建造列表
            ShowBuildingSelectList();
            //发送创建建筑消息 增加建筑信息，取消选中状态
            SendNotification(GlobalSetting.Cmd_ConfirmConstruction, _Building);
        }
    }

    private void Cancel()
    {
        //取消当前显示内容
        _CurrentIndicator.transform.SetParent(null);
        PoolManager.Instance.HideObjet(_CurrentIndicator.gameObject);
        PoolManager.Instance.HideObjet(_BuildingTF.gameObject);

        //清空建造数据
        _Building = null;
        _BuildingTF = null;
        _CurrentIndicator = null;
        //变更显示界面
        ShowBuildingSelectList();
        //取消选中拖拽操作
        SendNotification(GlobalSetting.Cmd_CancelConstruction);
    }

    private void RotateBuilding()
    {
        _Building.Rotate();

        _BuildingTF.localRotation = Quaternion.Euler(0, _Building.RotateValue, 0);

        _CurrentIndicator.SetIsCanConfirm(_IsCanConfirmFunc());
    }

    private void ShowBuildingInfo()
    {
        
    }

    private void CreateBuilding(E_Building mainBase)
    {
        string prefabName = "";
        string indicatorName = "";
        _CurrentIndicator = null;
        _BuildingTF = null;
        _Building = null;
        switch (mainBase)
        {
            case E_Building.None:
                break;
            case E_Building.MainBase:
                prefabName = "MainBase";
                indicatorName = ConstructionHUD1Name;
                MainBaseVO vo = new MainBaseVO();
                vo.IsMain = false;
                vo.PrefabName = MainBaseVO.SubPrefabName;
                _Building = vo;
                _IsCanConfirmFunc = () => IsCanBuildMainBase(vo);
                break;
            case E_Building.FarmLand:
                prefabName = "FarmLand";
                indicatorName = ConstructionHUD4Name;
                _Building = new FarmLandVO();
                _IsCanConfirmFunc = () => _UserProxy.IsCanConstructionUserBuilding(0, _Building);
                break;
            case E_Building.GoldMine:
                prefabName = "GoldMine";
                indicatorName = ConstructionHUD4Name;
                _Building = new GoldMineVO();
                _IsCanConfirmFunc = () => _UserProxy.IsCanConstructionUserBuilding(0, _Building);
                break;
            case E_Building.MilitaryCamp:
                prefabName = "MilitaryCamp";
                indicatorName = ConstructionHUD4Name;
                _Building = new MilitaryCampVO();
                _IsCanConfirmFunc = () => _UserProxy.IsCanConstructionUserBuilding(0, _Building);
                break;
            default:
                break;
        }

        _CurrentIndicator = PoolManager.Instance.GetObject(indicatorName, LoadAssetType.Normal, null).GetComponent<HUDConstruction>();

        if (_CurrentIndicator == null || string.IsNullOrEmpty(prefabName)) return;

        _BuildingTF = PoolManager.Instance.GetObject(prefabName, LoadAssetType.Normal, null).transform;
        _CurrentIndicator.transform.SetParent(_BuildingTF);
        _CurrentIndicator.transform.localPosition = Vector3.zero;
        _CurrentIndicator.transform.localRotation = Quaternion.identity;

        _BuildingTF.SetParent(_BuildingParnet);
        _BuildingTF.localRotation = Quaternion.identity;
        _Building.TilePositon = _MapProxy.ViewPositionToMap(new Vector3(0.5f, 0.5f, 0));
        _BuildingTF.localPosition = _Building.TilePositon + Vector3.up * 0.58f;
        SendNotification(GlobalSetting.Cmd_ShowConstruction, _BuildingTF);

        ShowBuildingSetup(_BuildingTF);

        _CurrentIndicator.SetIsCanConfirm(_IsCanConfirmFunc());
    }

    public void ShowBuildingSelectList()
    {
        uiForm.ShowBuildingSelectList();
        _IsShowBuildingList = true;
    }

    public void ShowBuildingSetup(Transform selectObj)
    {
        uiForm.ShowBuildingSetup();
        _IsShowBuildingList = false;
    }

    public void MoveBuilding(Vector3Int mapPosition)
    {
        _Building.TilePositon = mapPosition;

        _CurrentIndicator.SetIsCanConfirm(_IsCanConfirmFunc());
    }

    public bool IsCanBuildMainBase(MainBaseVO vo)
    {
        return _MapProxy.IsCanOccupedArea(vo.TilePositon, vo.Radius);
    }
}

