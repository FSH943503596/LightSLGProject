using UnityEngine;
using System.Collections;
using HedgehogTeam.EasyTouch;
using System;

public class SLGInputSystem :IBattleSystem<BattleManager>
{
    public SLGInputSystem(IBattleManager mgr) : base(mgr) { }

    private Transform cameraRoot;
    private Camera camera;

    private Transform longTapItem;
    private Transform dragItem;

    private ConstructionMediator constructionMediator;
    private MapVOProxy mapProxy;

    private Vector3Int lastDragPosition;

    private int groundLayerMask;

    public Transform LongTapItem { get => longTapItem; set => longTapItem = value; }
    public Transform DragItem { get => dragItem; set => dragItem = value; }

    public override void Initialize()
    {
        camera = GameObject.FindGameObjectWithTag(GlobalSetting.TAG_BATTLE_SCENE_CAMERA_NAME).GetComponent<Camera>();
        cameraRoot = camera.transform.parent;

        constructionMediator = facade.RetrieveMediator(ConstructionMediator.NAME) as ConstructionMediator;
        mapProxy = facade.RetrieveProxy(MapVOProxy.NAME) as MapVOProxy;

        groundLayerMask = LayerMask.GetMask(GlobalSetting.LAYER_MASK_NAME_GROUND);
    }

    public override void Update () {

#if UNITY_EDITOR || UNITY_STANDALONE
        if (Input.GetKeyDown(KeyCode.UpArrow))
        {
            camera.fieldOfView += 1000 * Time.deltaTime;
        }
        else if (Input.GetKeyDown(KeyCode.DownArrow))
        {
            camera.fieldOfView -= 1000 * Time.deltaTime;
        }
#endif

        Gesture current = EasyTouch.current;

        if (current == null) return;

        if (current.type == EasyTouch.EvtType.On_SimpleTap && current.pickedObject == null && !dragItem)
        {
        
            if (!constructionMediator.IsShowBuildingList)
            {
                longTapItem = null;
                constructionMediator.ShowBuildingSelectList();
            }
        }

        if (current.type == EasyTouch.EvtType.On_LongTapStart && current.pickedObject != null)
        {
            longTapItem = current.pickedObject.transform.parent;
            
            if (longTapItem != null)
            {
                Debug.LogError(longTapItem.name);
      
                constructionMediator.ShowBuildingSetup(longTapItem);
            }         
        }

        if (current.type == EasyTouch.EvtType.On_DragStart && current.pickedObject != null)
        {
            if (longTapItem == current.pickedObject.transform.parent)
            {
                dragItem = current.pickedObject.transform.parent;
                SaveLastPosition(current);
            }
        }

        if (current.type == EasyTouch.EvtType.On_Drag && current.pickedObject != null)
        {
            if (dragItem == current.pickedObject.transform.parent)
            {
 
                Vector3 pos = GetCurrentPointInMap(current.position);

                if (pos == default(Vector3)) return;

                if (Vector3.SqrMagnitude(lastDragPosition - pos) > 0.8)
                {
                    pos = dragItem.parent.worldToLocalMatrix * pos;
                    Vector3Int temp = new Vector3Int((int)pos.x, 0, (int)pos.z);
                    dragItem.localPosition = temp + Vector3.up * 0.58f;
                    constructionMediator.MoveBuilding(temp);
                    SaveLastPosition(current);
                }
            }
        }

        if (current.type == EasyTouch.EvtType.On_Swipe && current.touchCount == 1)
        {
            cameraRoot.Translate(Vector3.left * current.deltaPosition.x / Screen.width * 20);
            cameraRoot.Translate(Vector3.back * current.deltaPosition.y / Screen.height * 20);
        }


        if (current.type == EasyTouch.EvtType.On_Pinch)
        {
            camera.fieldOfView += current.deltaPinch * 10 * Time.deltaTime;
        }
    }

    private void SaveLastPosition(Gesture current)
    {
        Vector3 vector3 = GetCurrentPointInMap(current.position);
        vector3 = dragItem.worldToLocalMatrix * vector3;
        lastDragPosition = new Vector3Int((int)vector3.x, 0, (int)vector3.z);
    }

    private Vector3 GetCurrentPointInMap(Vector2 screenPosition)
    {
        Vector3 result = default(Vector3);

        Ray ray = camera.ScreenPointToRay(screenPosition);
        RaycastHit hitInfo;
        if (Physics.Raycast(ray, out hitInfo, 1000, groundLayerMask))
        {
            result =  new Vector3(hitInfo.point.x,0, hitInfo.point.z);
        }

        return result;
    }
}