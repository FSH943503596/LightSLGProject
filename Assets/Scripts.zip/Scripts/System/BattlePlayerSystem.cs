/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-22-17:59:32
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using System;
using UnityEngine;

public class BattlePlayerSystem : IBattleSystem<BattleManager>
{
    private PlayerVOProxy playerProxy;
    private BattleBuildingSystem buildingSystem;
    private BattleMapSystem mapSystem;
    private PlayerVO userPlayer;
    private Vector3 userMainBasePosition;
    public BattlePlayerSystem(IBattleManager mgr) : base(mgr)
    {
        buildingSystem = battleManager.buildingSystem;
        mapSystem = battleManager.mapSystem;
    }
    public Vector3 UserMainBasePosition { get => userMainBasePosition; }

    public void InitPlayers()
    {
        playerProxy = facade.RetrieveProxy("PlayerProxy") as PlayerVOProxy;

        //创建玩家
        userPlayer = playerProxy.CreatePlayer("我是玩家", 1);
        //创建建筑数据对象
        MainBaseVO mainBaseVO = buildingSystem.CreateMainBase(userPlayer);
        //获取指定基地所在地图的位置
        mainBaseVO.TilePositon = mapSystem.GetWalkableTileInRect(0.125f, 0.375f, 0.125f, 0.375f);
        //将建筑放到地图中
        mapSystem.AddBuildingInfo(mainBaseVO);
        //修改地块信息
        mapSystem.ChangeMapTileInfos(mainBaseVO.StartTilePositonInMap, GlobalSetting.MAINBASE_ORIGINAL_TILES);

        userMainBasePosition = mapSystem.MapPositionToWorld(mainBaseVO.TilePositon);

        //创建敌军
        PlayerVO enemy = playerProxy.CreatePlayer("我是敌人", 2);
        //创建建筑数据对象
        mainBaseVO = buildingSystem.CreateMainBase(enemy);
        //获取指定基地所在地图的位置
        mainBaseVO.TilePositon = mapSystem.GetWalkableTileInRect(0.625f, 0.875f, 0.625f, 0.875f);
        //将建筑放到地图中
        mapSystem.AddBuildingInfo(mainBaseVO);
        //修改地块信息
        mapSystem.ChangeMapTileInfos(mainBaseVO.StartTilePositonInMap, GlobalSetting.MAINBASE_ORIGINAL_TILES);

        //创建中立
        PlayerVO neutralPlayer;
        for (int i = 0; i < 2; i++)
        {
            neutralPlayer = playerProxy.CreatePlayer("和气生财" + 1, 0);
            //创建建筑数据对象
            mainBaseVO = buildingSystem.CreateMainBase(neutralPlayer);
            //获取指定基地所在地图的位置
            mainBaseVO.TilePositon = mapSystem.GetWalkableTileInRect(0.125f + i * 0.5f, 0.375f + i * 0.5f, 0.625f - i * 0.5f, 0.875f - i * 0.5f);
            //将建筑放到地图中
            mapSystem.AddBuildingInfo(mainBaseVO);
            //修改地块信息
            mapSystem.ChangeMapTileInfos(mainBaseVO.StartTilePositonInMap, GlobalSetting.MAINBASE_ORIGINAL_TILES);
        }
    }
}

