/*
 *	Author:	贾树永
 *	CreateTime:	2019-02-22-15:33:33
 *	Vertion: 1.0	
 *
 *	Description:
 *
*/

using System;

public class BattleBuildingSystem : IBattleSystem<BattleManager>
{
    private BattleMapSystem mapSystem;
    private MainBaseVOProxy mainBaseVOProxy;
    public BattleBuildingSystem(IBattleManager battleMgr) : base(battleMgr)
    {
        mapSystem = battleManager.mapSystem;
        mainBaseVOProxy = facade.RetrieveProxy(MainBaseVOProxy.NAME) as MainBaseVOProxy;
    }

    public MainBaseVO CreateMainBase(PlayerVO ower)
    {
        return mainBaseVOProxy.CreateMainBase(ower);
    }
}

